package pro.adminn;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pro.DB;


@WebServlet("/updatetopic")
public class updatetopic extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();  
        response.setContentType("text/html"); 
        String s1=request.getParameter("tname");
        String s2=request.getParameter("sname");
        String s3=request.getParameter("time");
        String s4=request.getParameter("topic");
		try 	
          {  
              Connection con =DB.getConnection();    
              PreparedStatement ps=con.prepareStatement("update booking set tname=?,sname=?,time=? where topic=?");
  			ps.setString(1,s1);
  			ps.setString(2,s2);
  			ps.setString(3,s3);
  			ps.setString(4,s4);
  			int x=ps.executeUpdate();                     
              con.close();  
              if(x!=0) {
            request.setAttribute("msg", "Updated Sucessfully");
              request.getRequestDispatcher("subtopic.jsp").forward(request,response);
              }
             }  
              catch (Exception e) 
             {  
              out.println("error");  
          }
	}

}
