package pro.adminn;

import java.sql.Connection;
import java.sql.PreparedStatement;

import pro.DB;

public class adminDaoImpl implements adminDao{
	static Connection con;
	static PreparedStatement ps;

	@Override
	public int inserttopic(String topic, String sdate, String edate, String cri) {

		int s=0;
		try {
			con=DB.getConnection();
			ps=con.prepareStatement("insert into topic values(?,?,?,?)");
			ps.setString(1,topic);
			ps.setString(2,sdate);
			ps.setString(3,edate);
			ps.setString(4,cri);
			s=ps.executeUpdate();
			//System.out.println("success");
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return s;

	}

	@Override
	public int insertIssueAns(int id, String sol) {
		int s=0;
		try {
			con=DB.getConnection();
			ps=con.prepareStatement("update help set ans=? where sno=?");
			ps.setString(1,sol);
			ps.setInt(2,id);
			s=ps.executeUpdate();
			//System.out.println("success");
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return s;
	}

}
