package pro.adminn;

public interface adminDao {
	public int inserttopic(String topic,String sdate,String edate,String cri);
	public int insertIssueAns(int id,String sol);

}
