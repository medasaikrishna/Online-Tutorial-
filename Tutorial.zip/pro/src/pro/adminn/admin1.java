package pro.adminn;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/admin1")
public class admin1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String topic=request.getParameter("topic");
		String sdate=request.getParameter("sdate");
		String edate=request.getParameter("edate");
		String cri=request.getParameter("cri");
		if(topic.length()==0||sdate.length()==0||edate.length()==0||cri.length()==0)
		{
			request.setAttribute("message","Enter complete data");
			 RequestDispatcher rd= request.getRequestDispatcher("addtopic.jsp");
	            rd.include(request, response);
		}
		else
		{
		adminDaoImpl adl=new adminDaoImpl();
		int x=adl.inserttopic(topic, sdate, edate, cri);
		if(x!=0)
		{
			request.setAttribute("message","Topic added successfully");
			 RequestDispatcher rd= request.getRequestDispatcher("addtopic.jsp");
	            rd.include(request, response);
//			request.getRequestDispatcher(".jsp").forward(request,response);
		}
		}
	
	}
	}


