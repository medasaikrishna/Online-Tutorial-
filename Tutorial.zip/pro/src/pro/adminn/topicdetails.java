package pro.adminn;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pro.DB;

@WebServlet("/topicdetails")
public class topicdetails extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String topic=request.getParameter("topic");
	if(topic!=null)
	{
		PrintWriter out = response.getWriter();  
        response.setContentType("text/html");  
        out.println("<html><body>");
        out.println("<style>");
        out.println(".abbc{padding-top:20px;\r\n" +
        		"padding-left:10px;\r\n" +
        		"padding-bottom:10px;\r\n" +
        		"background-color:skyblue;\r\n" + 
        		"border-radius:10px;\r\n" +
        		"color:black;\r\n" + 
        		"margin-left:20px;\r\n");
        out.println("text-align:center;color:white;margin-right:20px;}");
        out.println("</style>");
        out.println("<div class='abbc'>");
        try 	
        {  
            Connection con =DB.getConnection();    
            PreparedStatement ps=con.prepareStatement("select * from booking where topic=?");
			ps.setString(1,topic);			
			ResultSet rs=ps.executeQuery(); 
            out.println("<table>");  
            out.println("<tr><th>Tutor Name</th><th>Booked By Student</th><th>Time Slot</th><th>Topic</th></tr>");  
            while (rs.next()) 
            {  
            	String s=rs.getString(1);
                String n = rs.getString(2);  
                String o = rs.getString(3);
                String t=rs.getString(4);
                out.println("<tr><td>" + s + "</td><td>" + n + "</td><td>" + o +"</td><td>" + t +"</td></tr>");   
            }  
            out.println("</table>");
            out.println("</div>");
            out.println("</body></html>");  
            con.close();  
            
            RequestDispatcher rd= request.getRequestDispatcher("subtopic.jsp");
            rd.include(request, response);
           }  
            catch (Exception e) 
           {  
            out.println("error");  
        }
	}
	
	
        if(request.getParameter("edit")!=null)
        {
        	
        	PrintWriter out = response.getWriter();  
            response.setContentType("text/html");  
            out.println("<html><body>");
            out.println("<style>");
            out.println(".ac{padding-top:20px;\r\n" +
            		"padding-left:10px;\r\n" +
            		"padding-bottom:10px;\r\n" +
            		"background-color:skyblue;\r\n" + 
            		"border-radius:10px;\r\n" +
            		"color:black;\r\n" + 
            		"margin-left:20px;\r\n");
            out.println("text-align:center;color:white;margin-right:20px;}");
            out.println("</style>");
            out.println("<div class='ac'>");
            out.println("<form action='updatetopic' method='post'>");
            out.println("<table>"); 
            out.println("<tr><td>Tutor Name : </td><td><input type='text' name='tname'></td></tr>");
            out.println("<tr><td>Student Name : </td><td><input type='text' name='sname'></td></tr>");
            out.println("<tr><td>Time Slot : </td><td><input type='text' name='time'></td></tr>");
            out.println("<tr><td>Topic : </td><td><input type='text' name='topic'></td></tr>");
            out.println("</table><br><br>"); 
            out.println("<input type='submit' name='submit' value='Submit'>");
            out.println("</form>");
            out.println("</div>");
            out.println("</html></body>");
      
        }
        
	

	}

}
