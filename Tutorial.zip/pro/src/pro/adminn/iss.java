package pro.adminn;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pro.DB;

@WebServlet("/iss")
public class iss extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		if(request.getParameter("add")!=null)
		{
			request.getRequestDispatcher("addtopic.jsp").forward(request,response);
		}
		if(request.getParameter("sub")!=null)
		{
			request.getRequestDispatcher("subtopic.jsp").forward(request,response);
		}
		
		if(request.getParameter("resolve")!=null)
		{
			PrintWriter out = response.getWriter();  
	        response.setContentType("text/html");  
	        out.println("<html><body>");
	        out.println("<style>");
	        out.println(".abc{padding-top:20px;\r\n" +
	        		"padding-left:10px;\r\n" +
	        		"padding-bottom:10px;\r\n" +
	        		"background-color:skyblue;\r\n" + 
	        		"border-radius:10px;\r\n" +
	        		"color:black;\r\n" + 
	        		"margin-left:20px;\r\n");
	        out.println("text-align:center;color:white;margin-right:20px;}");
	        out.println("</style>");
	        out.println("<br>");
	        out.println("<div class='abc'>");
	        try 	
	        {  
	            Connection con =DB.getConnection();  
	            Statement stmt = con.createStatement();  
	            ResultSet rs = stmt.executeQuery("select * from help where ans is null");  
	            out.println("<table>");  
	            out.println("<tr><th>Issue ID</th><th>Issue About</th><th>Issue Description</th></tr>");  
	            while (rs.next()) 
	            {  
	            	String s=rs.getString(1);
	                String n = rs.getString(2);  
	                String o = rs.getString(3);
	                out.println("<tr><td>" + s + "</td><td>" + n + "</td><td>" + o +"</td></tr>");   
	            }  
	            out.println("</table>");
	            out.println("</div>");
	            out.println("<br>");
	            out.println("</body></html>");  
	            con.close();  
	            
	            RequestDispatcher rd= request.getRequestDispatcher("admin.jsp");
	            rd.include(request, response);
	           }  
	            catch (Exception e) 
	           {  
	            out.println("error");  
	        }
		}
		else
		{
		adminDaoImpl adl=new adminDaoImpl();
		int issue=Integer.parseInt(request.getParameter("issue"));
		String sol=request.getParameter("comment");
		int x=adl.insertIssueAns(issue, sol);
		if(x!=0)
		{
			PrintWriter out = response.getWriter();
			out.println("<html><body>");
			out.println("<h2 style='color:green'>Issue Solved</h2>");
			RequestDispatcher rd= request.getRequestDispatcher("admin.jsp");
            rd.include(request, response);
		}
		}
	}

}
