package pro;


import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.sql.*;
import java.util.*;

public class DB {

	private static Connection con = null;
	private static Properties props = new Properties();
	
    
	

    //ENSURE YOU DON'T CHANGE THE BELOW CODE WHEN YOU SUBMIT
	public static Connection getConnection() throws ClassNotFoundException, SQLException {
	    try{
			
			FileInputStream fis = null;
			fis = new FileInputStream("C:\\Users\\medas\\eclipse-workspace\\pro\\WebContent\\database.properties");
			props.load(fis);
			//System.out.println("hi1");
			// load the Driver Class
			Class.forName(props.getProperty("DB_DRIVER_CLASS"));
			//System.out.println("hi2");
			// create the connection now
            con = DriverManager.getConnection(props.getProperty("DB_URL"),props.getProperty("DB_USERNAME"),props.getProperty("DB_PASSWORD"));
            //System.out.println("hi3");
	    }
	    catch(IOException e){
	        e.printStackTrace();
	    }
		return con;	
	}
}
