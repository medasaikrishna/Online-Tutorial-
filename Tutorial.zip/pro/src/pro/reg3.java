package pro;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.util.*;

@WebServlet("/reg3")
public class reg3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
UserDaoImpl ud=new UserDaoImpl();
		
		String uname=request.getParameter("sname");
		String pass=request.getParameter("spass");
		
		admin adm=ud.adminDetails(uname, pass);
		
		
		String aid=adm.getAdminid();
		String apass=adm.getAdminpass();
		
		if(uname.equals(aid)&&pass.equals(apass))
		{
			
			HttpSession session=request.getSession();
			session.setAttribute("username",uname);
			//request.setAttribute("message",uname);
			request.getRequestDispatcher("admin.jsp").forward(request,response);
		}
		else
		{
			request.setAttribute("message","Password NOT Matching");
			request.getRequestDispatcher("logina.jsp").forward(request,response);
		}
	}

}
