package pro;

import java.util.Scanner;

public class UserMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		UserDetails ud=new UserDetails();
//		UserDaoImpl udi=new UserDaoImpl();
//		Scanner s=new Scanner(System.in);
//		System.out.println("enter user details");
//		ud.setFname(s.nextLine());
//		ud.setLname(s.nextLine());
//		ud.setDob(s.nextLine());
//		ud.setGender(s.nextLine());
//		ud.setNum(s.nextLine());
//		ud.setUserid(s.nextLine());
//		ud.setPass(s.nextLine());
//		
//		int x=udi.insert(ud);
//		System.out.println("User Details Saved");
		
	}

}
