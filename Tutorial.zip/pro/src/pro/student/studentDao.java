package pro.student;

public interface studentDao {

	public StuDetails getstu(String sid,String spass);
	public int insert(StuDetails sd);
	public int booking(String tname,String sname,String time,String topic);
	public int getbook(String tname,String time);
}
