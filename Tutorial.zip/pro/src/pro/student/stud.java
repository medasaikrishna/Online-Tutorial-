package pro.student;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pro.DB;

@WebServlet("/stud")
public class stud extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public stud() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		PrintWriter out = response.getWriter();  
        response.setContentType("text/html"); 
        out.println();
        out.println("<html><body>");
        out.println("<style>");
        out.println(".abc{padding-top:20px;\r\n" +
        		"padding-left:10px;\r\n" +
        		"padding-bottom:10px;\r\n" +
        		"background-color:skyblue;\r\n" + 
        		"border-radius:10px;\r\n" +
        		"color:black;\r\n" + 
        		"margin-left:20px;\r\n");
        out.println("text-align:center;color:white;margin-right:20px;}");
        out.println("</style>");
        out.println("<div class='abc'>");
        out.println("<b>Skills you required..</b><br>");
        out.println("<table style='padding:10px;'>"); 
        try 
        {  
            Connection con =DB.getConnection();  
            Statement stmt = con.createStatement(); 
            String srh=request.getParameter("search");
            ResultSet rs = stmt.executeQuery("select * from skills");
            out.println("<th>tname</th><th>Another Skills</th><th>Time Slots</th>");
            while (rs.next()) 
            {  
                String n1 = rs.getString(1);  
                String n2= rs.getString(2);
                String n3= rs.getString(3);
                if(n2.contains(srh))
                {
                out.println("<tr><td>"+n1+" "+"</td><td>"+n2+" "+"</td><td>"+n3+" "+"</td></tr>");  
                }
            }
            out.println("</table>"); 
            out.println("</div>");
            out.println("</body></html>");  
            con.close(); 
            
            RequestDispatcher rd= request.getRequestDispatcher("student.jsp");
            rd.include(request, response);
           }  
            catch (Exception e) 
           {  
            out.println("error");  
        } 
        
        
       
	}


}
