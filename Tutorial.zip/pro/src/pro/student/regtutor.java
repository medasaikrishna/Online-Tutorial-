package pro.student;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pro.DB;


@WebServlet("/regtutor")
public class regtutor extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		PrintWriter out=response.getWriter();
//		if(request.getParameter("getslot")!=null)
//		{
//			String slt="",str="";
//			try {
//				 Connection con=DB.getConnection();
//				 PreparedStatement ps=con.prepareStatement("select slots from troom");
//				   ResultSet rs = ps.executeQuery();
//				   
//				   while(rs.next())
//				   {
//					    slt=rs.getString(1);
//					    PreparedStatement ps2=con.prepareStatement("select slot from stureg");
//						   ResultSet rs2 = ps2.executeQuery();
//						   
//						   while(rs2.next())
//						   {
//							    str=rs2.getString(1);
//						   }
//				   }
//				   String s[]=slt.split(",");
//				  
//				   for(int i=0;i<s.length;i++)
//				   {
//					   if(s[i].equals(str))
//						   continue;
//					   else
//						   out.println(s[i]);
//				   }
//				   RequestDispatcher rd= request.getRequestDispatcher("gettur.java");
//		            rd.include(request, response);
//				
//			}
//			catch(Exception e)
//			{
//				System.out.println(e);
//			}
//		}
		try {
			String slot="";
			String sbj="";
			int f=0;
			String str=request.getParameter("slot");
			String sub=request.getParameter("sub");
			 Connection con=DB.getConnection();
			 PreparedStatement ps2=con.prepareStatement("select slot,sub from stureg");
			   ResultSet rs2 = ps2.executeQuery();
			   
			   while(rs2.next())
			   {
				    slot+=rs2.getString(1)+",";
				    sbj=rs2.getString(2);
			   }
			   if(sub.equals(sbj))
				   f=1;
			   if(slot.contains(str)&&f==1)
			   {
				   request.setAttribute("message","Selected Time Slot is Not Available");
					request.getRequestDispatcher("class.jsp").forward(request,response);   
			   }
			   else
			   {
			 PreparedStatement ps=con.prepareStatement("insert into stureg(tid,sname,slot,sub,tdate) values(?,?,?,?,?)");
			ps.setString(1,request.getParameter("tid"));
			ps.setString(2,request.getParameter("sname"));
			ps.setString(3,request.getParameter("slot"));
			ps.setString(4,request.getParameter("sub"));
			ps.setString(5,request.getParameter("dat"));
			int s=ps.executeUpdate();
			//System.out.println("success");
			if(s!=0)
			{
				request.setAttribute("message","Successfully Registered");
				request.getRequestDispatcher("class.jsp").forward(request,response);
			}
			   }
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
