package pro.student;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import pro.DB;


@WebServlet("/viewrev")
public class viewrev extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		String uid=(String)session.getAttribute("username");
		String id=(String)request.getAttribute("username");
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");  
		//out.println(uid);
		//out.println(id);
        out.println("<html><body>");
        out.println("<style>");
        out.println(".abc{padding-top:20px;\r\n" +
        		"padding-left:10px;\r\n" +
        		"padding-bottom:10px;\r\n" +
        		"background-color:skyblue;\r\n" + 
        		"border-radius:10px;\r\n" +
        		"color:black;\r\n" + 
        		"margin-left:20px;\r\n");
        out.println("text-align:center;color:white;margin-right:20px;}");
        out.println("</style>");
        out.println("<div class='abc'>");
        out.println("<form action='getrev' method='get'>");
        try 
        {  
            Connection con =DB.getConnection();  
            PreparedStatement ps = con.prepareStatement("select * from paper where sname=?");
            ps.setString(1, uid);
            ResultSet rs = ps.executeQuery();  
            out.println("<table>");
            out.println("<h2 style='color:green;'>Reviews</h2>");
            out.println("<tr><th>Paper</th><th>Review</th></tr>");  
            while (rs.next()) 
            {  
            	String s=rs.getString(2);
                String n = rs.getString(5);  
           
                out.println("<tr><td>" + s + "</td><td><button type='submit' name='top' value="+s+">Get Review</button>");   
            } 
            
            out.println("</table><br><br>");
			out.println("</form>");
			out.println("</div><br>");
			out.println("<br>");
			out.println("<a href='student.jsp'><button type='submit'>Back</button></a>");
            out.println("</body></html>");  
            con.close();
           // RequestDispatcher rd= request.getRequestDispatcher(".jsp");
           //rd.include(request, response);
           
           }  
            catch (Exception e) 
           {  
            out.println("error");  
        }  
		
		
	}



}
