package pro.student;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pro.DB;


@WebServlet("/getrev")
public class getrev extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String top=request.getParameter("top");
		PrintWriter out=response.getWriter();
		response.setContentType("text/html"); 
        out.println("<html><body>");
        out.println("<style>");
        out.println(".abc{padding-top:20px;\r\n" +
        		"padding-left:10px;\r\n" +
        		"padding-bottom:10px;\r\n" +
        		"background-color:skyblue;\r\n" + 
        		"border-radius:10px;\r\n" +
        		"text-align:center;\r\n" + 
        		"margin-left:20px;\r\n");
        out.println("text-align:center;color:white;margin-right:20px;}");
        out.println("</style>");
        out.println("<div class='abc'>");
        out.println("<form>");
        try 
        {  
            Connection con =DB.getConnection();  
            PreparedStatement ps = con.prepareStatement("select review from paper where about=?");
            ps.setString(1,top);
            ResultSet rs = ps.executeQuery();  
            out.println("<table>");
            out.println("<h2>Review</h2>");  
            while (rs.next()) 
            {  
            	String s=rs.getString(1);           
                out.println("<tr><td>" + s + "</td></tr>");   
            } 
            
            out.println("</table><br><br>");
			out.println("</form>");
			out.println("</div>");
			out.println("<br>");
			out.println("<a href='student.jsp'><button type='submit'>Back</button></a>");
            out.println("</body></html>");  
            con.close();  
           
           }  
            catch (Exception e) 
           {  
            out.println("error");  
        }  
	}


}
