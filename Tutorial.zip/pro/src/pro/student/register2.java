package pro.student;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class register2
 */
@WebServlet("/register2")
public class register2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public register2() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		studentDaoImpl ud=new studentDaoImpl();
		StuDetails usd=new StuDetails();
		String fname=request.getParameter("fname");
		String sname=request.getParameter("dob");
		String email=request.getParameter("num");
		usd.setSid(fname);
		usd.setSpass(request.getParameter("lname"));
		usd.setSname(sname);
		usd.setSemail(email);
		
		if(fname.equalsIgnoreCase("null")||sname.equalsIgnoreCase("null")||email.equalsIgnoreCase("null"))
		{
			out.println("<script type='text/javascript'>");
        	out.println("alert('Fields Cannot be Null');");
        	out.println("</script>");
        	RequestDispatcher rd=request.getRequestDispatcher("register2.html");
        	rd.include(request, response);
		}
		else {
		int x=ud.insert(usd);
		if(x!=0)
		{
		request.setAttribute("sussmessage","New User created Successfully");
		request.getRequestDispatcher("login.jsp").forward(request,response);
		}
		else
		{
			request.setAttribute("sussmessage","Not registered !!!!");
			request.getRequestDispatcher("login.jsp").forward(request,response);
		}
		}
	}

}
