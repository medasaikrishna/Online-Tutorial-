package pro.student;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/sub")
public class sub extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        	if(request.getParameter("back")!=null)
        	{
        		request.getRequestDispatcher("student.jsp").forward(request,response);
        	}
        	PrintWriter out = response.getWriter();  
            response.setContentType("text/html");  
            out.println("<html><body>");
            out.println("<style>");
            out.println(".abc{padding-top:20px;\r\n" +
            		"padding-left:10px;\r\n" +
            		"padding-bottom:10px;\r\n" +
            		"background-color:skyblue;\r\n" + 
            		"border-radius:10px;\r\n" +
            		"color:black;\r\n" + 
            		"margin-left:20px;\r\n");
            out.println("text-align:center;color:white;margin-right:20px;}");
            out.println("</style>");
            out.println("<div class='abc'>");
            out.println("<form action='subpaper' enctype='multipart/form-data' method='post'>");
            out.println("<table>");
            out.println("<tr><td>Student Name : </td><td><input type='text' name='sname'></td></tr>");
            out.println("<tr><td>About Paper : </td><td><input type='text' name='apap'></td></tr>");
            out.println("<br>");
            out.println("<tr><td>Upload Paper : </td><td><input type='file' name='submitpaper'></td></tr>");
            out.println("</table><br>"); 
            out.println("<input type='submit' name='submit' value='Submit'>");
            out.println("</form>");
            out.println("</div>");
            out.println("</html></body>");
      
        
	}

}
