package pro.student;

public class StuDetails {
private String sid;
private String spass;
private String sname;
private String semail;
private String que;
private String ans;

public String getQue() {
	return que;
}
public void setQue(String que) {
	this.que = que;
}
public String getAns() {
	return ans;
}
public void setAns(String ans) {
	this.ans = ans;
}
public String getSid() {
	return sid;
}
public void setSid(String sid) {
	this.sid = sid;
}
public String getSpass() {
	return spass;
}
public void setSpass(String spass) {
	this.spass = spass;
}
public String getSname() {
	return sname;
}
public void setSname(String sname) {
	this.sname = sname;
}
public String getSemail() {
	return semail;
}
public void setSemail(String semail) {
	this.semail = semail;
}


}
