package pro.student;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/stud2")
public class stud2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

				if(request.getParameter("paper")!=null)
				{
					//request.setAttribute("msg","Tutor is Not avaliable at this slot");
	        		request.getRequestDispatcher("paper.jsp").forward(request,response);
				}
	        	String tname=request.getParameter("tname");
	        	String time=request.getParameter("time");
	        	String sname=request.getParameter("sname");
	        	String topic=request.getParameter("topic");
	        	studentDaoImpl sdl=new studentDaoImpl();
	        	int s=sdl.getbook(tname, time);
	        	if(s==1)
	        	{
	        		sdl.booking(tname, sname, time,topic);
	        		request.setAttribute("msg","Your Booking is successfully done with the tutor");
	        		request.getRequestDispatcher("student.jsp").forward(request,response);
	        	}
	        	else
	        	{
	        		
	        		request.setAttribute("msg","Tutor is Not avaliable at this slot");
	        		request.getRequestDispatcher("student.jsp").forward(request,response);
	        	}
	        
	}

}
