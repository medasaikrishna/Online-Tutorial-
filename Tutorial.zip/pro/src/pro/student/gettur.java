package pro.student;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pro.DB;


@WebServlet("/gettur")
public class gettur extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String id=request.getParameter("topic");
		PrintWriter out = response.getWriter();  
        response.setContentType("text/html");  
        out.println("<html><body>"); 
        out.println("<style>");
        out.println(".aa{padding-top:20px;\r\n" +
        		"padding-left:10px;\r\n" +
        		"padding-bottom:10px;\r\n" +
        		"background-color:#31D5C1;\r\n" + 
        		"border-radius:10px;\r\n" +
        		"color:black;\r\n" + 
        		"margin-left:20px;\r\n");
        out.println("text-align:center;color:white;margin-right:20px;}");
        out.println(".aac{padding-top:20px;\r\n" +
        		"padding-left:10px;\r\n" +
        		"padding-bottom:10px;\r\n" +
        		"background-color:#31BFD5;\r\n" + 
        		"border-radius:10px;\r\n" +
        		"color:black;\r\n" + 
        		"margin-left:20px;\r\n");
        out.println("text-align:center;color:white;margin-right:20px;}");
        out.println("</style>");
        try 
        {  
            Connection con =DB.getConnection();  
            PreparedStatement stmt = con.prepareStatement("select * from troom where tid=?");
            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();  
            out.println("<div class='aa'>");
            out.println("<table>");  
            out.println("<tr><th>Tutor ID</th><th>Subject</th><th>Date</th><th>Venue</th><th>Time Slots</th><th>Fee</th></tr>");  
            while (rs.next()) 
            {  
                String n1 = rs.getString(1);
                String n2 = rs.getString(2);
                String n3 = rs.getString(3);
                String n4 = rs.getString(4);
                String n5 = rs.getString(5);
                String n6 = rs.getString(6);
           
                out.println("<tr><td>" + n1 +"</td><td>" + n2 + "</td><td>" + n3 + "</td><td>" + n4 + "</td><td>" + n5 + "</td><td>" + n6 + "</td></tr>");   
            }  
            out.println("</table>");
            out.println("</div>");
            out.println("<div class='aac'>");
            out.println("<form action='regtutor' method='post'>");
            out.println("<table>");
            out.println("<tr><td>Tutor ID : </td><td><input type='text' name='tid' required></td></tr>");
            out.println("<tr><td>Student Name : </td><td><input type='text' name='sname' required></td></tr>");
            out.println("<tr><td>Slot : </td><td><input type='text' name='slot' required></td></tr>");
            out.println("<tr><td>Sub : </td><td><input type='text' name='sub' required></td></tr>");
            out.println("<tr><td>Date : </td><td><input type='text' name='dat' required></td></tr>");
            out.println("<tr><td><input type='submit' name='submit' value='Register' required></td></tr>");
            out.println("</table>");
            out.println("</form>");
            out.println("</div>");
            out.println("</html></body>");  
            con.close();  
            
            RequestDispatcher rd= request.getRequestDispatcher("class.jsp");
            rd.include(request, response);
           }  
            catch (Exception e) 
           {  
            out.println("error");  
        }  
	}


}
