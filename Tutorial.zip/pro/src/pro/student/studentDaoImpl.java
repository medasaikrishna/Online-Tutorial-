package pro.student;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import pro.DB;

public class studentDaoImpl implements studentDao{

	static Connection con;
	static PreparedStatement ps;
	@Override
	public StuDetails getstu(String sid, String spass) {
		StuDetails udd=new StuDetails();
		try
		{
			con=DB.getConnection();
			ps=con.prepareStatement("select * from student where sid=? and spass=?");
			ps.setString(1,sid);
			ps.setString(2,spass);
			
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				udd.setSid(rs.getString(1));
				udd.setSpass(rs.getString(2));
				udd.setSname(rs.getString(3));
				udd.setSemail(rs.getString(4));
			}
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return udd;
	}
	@Override
	public int insert(StuDetails sd) {

		int s=0;
		try {
			con=DB.getConnection();
			ps=con.prepareStatement("insert into student values(?,?,?,?)");
			ps.setString(1,sd.getSid());
			ps.setString(2,sd.getSpass());
			ps.setString(3,sd.getSname());
			ps.setString(4,sd.getSemail());
			s=ps.executeUpdate();
			//System.out.println("success");
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return s;
	}
	@Override
	public int booking(String tname, String sname, String time,String topic) {
		int s=0;
		try {
			con=DB.getConnection();
			ps=con.prepareStatement("insert into booking values(?,?,?,?)");
			ps.setString(1,tname);
			ps.setString(2,sname);
			ps.setString(3,time);
			ps.setString(4,topic);
			s=ps.executeUpdate();
			//System.out.println("success");
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return s;
	}
	@Override
	public int getbook(String tname, String time) {
		int s=0;
		String str1="null",str2="null";
		try {
			con=DB.getConnection();
			ps=con.prepareStatement("select * from booking where tname=? and time=?");
			ps.setString(1,tname);
			ps.setString(2,time);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				str1=rs.getString(1);
				str2=rs.getString(3);
			
			//System.out.println("success");
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		if(str1.equals("null")&& str2.equals("null"))
		return 1;
		else
			return 0;
	}

}
