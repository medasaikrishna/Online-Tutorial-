package pro.student;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/submit")
public class submit extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


		  if(request.getParameter("edit")!=null)
	        {
	        	
	        	PrintWriter out = response.getWriter();  
	            response.setContentType("text/html");  
	            out.println("<html><body>");
	            out.println("<form action='subpaper' method='post'>");
	            out.println("<table>"); 
	            out.println("<tr><td>About Paper : <input type='text' name='apap'></td></tr>");
	            out.println("<tr><td>Submit : <input type='file' name='sub'></td></tr>");
	            out.println("</table><br><br>"); 
	            out.println("<input type='submit' name='submit' value='Submit'>");
	            out.println("</form>");
	            out.println("</html></body>");
	      
	        }
	}

}
