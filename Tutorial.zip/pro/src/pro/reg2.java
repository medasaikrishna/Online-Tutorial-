package pro;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import pro.student.StuDetails;
import pro.student.studentDaoImpl;

@WebServlet("/reg2")
public class reg2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public reg2() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String uname=request.getParameter("sname");
		String pass=request.getParameter("spass");
		
		HttpSession session=request.getSession();
		session.setAttribute("username",uname);
		request.setAttribute("username", uname);
		studentDaoImpl adl=new studentDaoImpl();
		StuDetails sd=adl.getstu(uname, pass);
		String n1=sd.getSid();
		String n2=sd.getSpass();
       
		if(uname.equals(n1)&&pass.equals(n2))
		{
			
			//HttpSession session=request.getSession();
			//session.setAttribute("studentname",uname);
			request.setAttribute("message",uname);
			request.getRequestDispatcher("student.jsp").forward(request,response);
		}
		else
		{
			request.setAttribute("message","Invalid ID or Password");
			request.getRequestDispatcher("login.jsp").forward(request,response);
		}
	
	}

}
