package pro;

public class UserDetails {
private String fname;
private String lname;
private String dob;
private String gender;
private String num;
private String userid;
private String pass;
private String secretQ;
private String secretA;

public String getFname() {
	return fname;
}
public void setFname(String fname) {
	this.fname = fname;
}
public String getLname() {
	return lname;
}
public void setLname(String lname) {
	this.lname = lname;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getNum() {
	return num;
}
public void setNum(String num) {
	this.num = num;
}
public String getUserid() {
	return userid;
}
public void setUserid(String userid) {
	this.userid = userid;
}
public String getPass() {
	return pass;
}
public void setPass(String pass) {
	this.pass = pass;
}
public String getSecretQ() {
	return secretQ;
}
public void setSecretQ(String secretQ) {
	this.secretQ = secretQ;
}
public String getSecretA() {
	return secretA;
}
public void setSecretA(String secretA) {
	this.secretA = secretA;
}



}
