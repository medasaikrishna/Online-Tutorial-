package pro;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/help")
public class help extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter(); 
		String issue=request.getParameter("issue");
		String desc=request.getParameter("desc");
		UserDaoImpl udl=new UserDaoImpl();
		int x=udl.inserthelp(issue, desc);
		if(x!=0)
		{
			//request.setAttribute("skillmsg","Your Issue will be resolved soon!");
			//request.getRequestDispatcher("welcome.jsp").forward(request,response);
			out.println("<html><body>");
			out.println("<h3 style='color:green;'>Your Issue will be resolved</h3>");
			
			try 
	        {  
	            Connection con =DB.getConnection();  
	            Statement stmt = con.createStatement();
	            PreparedStatement ps=con.prepareStatement("select * from help where issue=?");
				ps.setString(1,issue);
	            ResultSet rs = ps.executeQuery();
	            
	            out.println("<table>");  
	            out.println("<tr><th>About Issue</th><th>Solution</th></tr>");  
	            while (rs.next()) 
	            {  
	            	String s=rs.getString(2);
	                String n1 = rs.getString(4);
	                if(n1!=null)
	                out.println("<tr><td>" + s + "</td><td>" + n1 + "</td></tr>");   
	            }  
	            out.println("</table boder=1>");  
	            out.println("</html></body>");  
	            con.close();  
	            
	            RequestDispatcher rd= request.getRequestDispatcher("issues.jsp");
	            rd.include(request, response);
	           }  
	            catch (Exception e) 
	           {  
	            out.println("error");  
	        }  
			
		}
	}

}
