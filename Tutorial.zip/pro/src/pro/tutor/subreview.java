package pro.tutor;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import pro.DB;


@WebServlet("/subreview")
public class subreview extends HttpServlet implements Servlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String rev=request.getParameter("review");
		PrintWriter out = response.getWriter();
		HttpSession session=request.getSession();
		String paper1=(String)session.getAttribute("skill");
		out.println(paper1);
		try 
        {  
            Connection con =DB.getConnection();  
            PreparedStatement stmt = con.prepareStatement("update paper set review=? where about=?"); 
            stmt.setString(1,rev);
            stmt.setString(2,paper1);
            int x = stmt.executeUpdate();  
            
            con.close();  
            
            request.setAttribute("revie","Your Review Saved Successfully");
            request.getRequestDispatcher("tutor.jsp").forward(request,response);
            
           }  
            catch (Exception e) 
           {  
            out.println("error");  
        } 
	}

}
