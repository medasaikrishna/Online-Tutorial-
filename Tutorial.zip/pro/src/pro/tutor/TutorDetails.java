package pro.tutor;

public class TutorDetails {
	private int tid;
	private String tname;
	private String skills;
	

}
