package pro.tutor;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import pro.DB;


@WebServlet("/getpaper")
public class getpaper extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter(); 
		if(request.getParameter("back")!=null)
		{
			request.getRequestDispatcher("welcome.jsp").forward(request,response);
		}
		else if(request.getParameter("review")!=null)
		{
			 	out.println("<html><body>");
			 	out.println("<style>");
		        out.println(".abc{padding-top:20px;\r\n" +
		        		"padding-left:10px;\r\n" +
		        		"padding-bottom:10px;\r\n" +
		        		"background-color:skyblue;\r\n" + 
		        		"border-radius:10px;\r\n" + 
		        		"margin-left:50px;\r\n");
		        out.println("text-align:center;color:white;margin-right:50px;}");
		        out.println("</style>");
		        out.println("<div class='abc'>");
		        out.println("<form action='subreview' method='post'>");
		        out.println("<table style='padding:10px;border:1px solid black;border-collapse:collapse;'>");
		        out.println("<b>Review : </b><textarea rows='5' cols='50' name='review'>Enter your comments...</textarea><br><br>");
		        out.println("<input type='submit' name='submit' value='Submit'>");
		        out.println("</table>"); 
		        out.println("</form>");
		        out.println("</div>");
	            out.println("</html></body>");
		}
		else {
		String paper1=request.getParameter("topic");
		 
        response.setContentType("text/html");
       // request.setAttribute("skill",paper1);
        
        HttpSession session=request.getSession();
        session.setAttribute("skill",paper1);
        String uid=(String)session.getAttribute("username");
        //out.println(paper1);
        out.println("<html><body>");
        out.println("<style>");
        out.println(".abab{padding-top:20px;\r\n" +
        		"padding-left:10px;\r\n" +
        		"padding-bottom:10px;\r\n" +
        		"background-color:skyblue;\r\n" + 
        		"border-radius:10px;\r\n" + 
        		"margin-left:25px;\r\n");
        out.println("text-align:center;color:white;margin-right:25px;}");
        out.println("</style>");
        out.println("<div class='abab'>");
        out.println("<table style='padding:10px;border:1px solid black;border-collapse:collapse;'>");
        out.println("<form action='dispaper' method='get'>");
        try 
        {  
            Connection con =DB.getConnection();  
            PreparedStatement  stmt = con.prepareStatement("select * from paper p,student s where p.sname=s.sid and p.about=?");
            stmt.setString(1, paper1);
            ResultSet rs = stmt.executeQuery();
            out.println("<th>User ID</th><th>User Name</th><th>User Email</th><th>Paper</th>");
            while (rs.next()) 
            {  
                String n1 = rs.getString(6);  
                String n2= rs.getString(8);
                String n3= rs.getString(9);              
                
                out.println("<tr><td>"+n1+" "+"</td><td>"+n2+" "+"</td><td>"+n3+" "+"</td><td><button name='skill' value='skill'>Get Paper</button></td></tr>");  
                
            }
            out.println("</table>");
            out.println("</div>");
            out.println("</html></body>");  
            con.close(); 
            
            RequestDispatcher rd= request.getRequestDispatcher("tutor.jsp");
            rd.include(request, response);
           }  
            catch (Exception e) 
           {  
            out.println("error");  
        } 
		} 
    }
	}



