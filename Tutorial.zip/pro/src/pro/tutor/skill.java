package pro.tutor;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import pro.DB;
import pro.UserDaoImpl;

@WebServlet("/skill")
public class skill extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter(); 
		//request.setAttribute("user",uid);
		UserDaoImpl udl=new UserDaoImpl();
		HttpSession session=request.getSession();
		//session .setAttribute("user",);
		
		String uid=(String)session.getAttribute("username");
		
		//session.setAttribute("username",user);
		//out.println(request.getAttribute("username"));
		if(request.getParameter("Edit")!=null)
		{
			String skl=udl.getSkill(uid);
			request.setAttribute("edit1",skl);
			request.setAttribute("edit2","Select new skills to update");
			request.getRequestDispatcher("newskills.jsp").forward(request,response);
		}
		if(request.getParameter("gettime")!=null)
		{
			 
	        response.setContentType("text/html");  
	        out.println("<html><body>");
	        out.println("<style>");
	        out.println(".abc{padding-top:20px;\r\n" +
	        		"padding-left:10px;\r\n" +
	        		"padding-bottom:10px;\r\n" +
	        		"background-color:skyblue;\r\n" + 
	        		"border-radius:10px;\r\n" + 
	        		"margin-left:50px;\r\n");
	        out.println("text-align:center;color:white;margin-right:50px;}");
	        out.println("</style>");
	        out.println("<form>");
	        try 
	        {  
	            Connection con =DB.getConnection();  
	            Statement stmt = con.createStatement();  
	            ResultSet rs = stmt.executeQuery("select * from booking"); 
	            out.println("<div class='abc'>");
	            out.println("<table>");  
	            out.println("<tr><th>Student Name</th><th>Booked Timeslot</th></tr>");  
	            while (rs.next()) 
	            {  
	            	String s=rs.getString(2);
	                String n = rs.getString(3);  
	           
	                out.println("<tr><td>" + s + "</td><td>" + n + "</td></tr>");   
	            }  
	            out.println("</table><br><br>");
	            out.println("</div>");
				out.println("</form>");
				out.println("<a href='welcome.jsp'><button type='submit' name='Home' value='Home'>Home Page</button></a>");
	            out.println("</body></html>");  
	            con.close();  
	            request.setAttribute("time","Timeslots Booked by Students");
//	            RequestDispatcher rd= request.getRequestDispatcher("welcome.jsp");
//	            rd.include(request, response);
	           }  
	            catch (Exception e) 
	           {  
	            out.println("error");  
	        }  
			
			//request.getRequestDispatcher("tutor.jsp").forward(request,response);
		
		}
		if(request.getParameter("view")!=null)
		{
			
			request.getRequestDispatcher("tutor.jsp").forward(request,response);
//			PrintWriter out = response.getWriter();  
//	        response.setContentType("text/html");  
//	        out.println("<html><body>"); 
//	        out.println("<form>");
//	        try 
//	        {  
//	            Connection con =DB.getConnection();  
//	            PreparedStatement stmt = con.prepareStatement("select skill from skills where uid=?"); 
//	            stmt.setString(1, user);
//	            ResultSet rs = stmt.executeQuery();  
//	            out.println("<table>");  
//	            out.println("<tr><th>Topic Name</th></tr>");  
//	            while (rs.next()) 
//	            {  
//	            	String s=rs.getString(2);
//	            	String a[]=s.split(",");
//	            	for(int i=0;i<a.length;i++)
//	            	out.println("<tr><td><button name=''>" + a[i] + "</td></tr>");   
//	            			           
//	            }  
//	            out.println("</table>");
//	            out.println("</form>");
//	            out.println("</html></body>");  
//	            con.close();  
//	            
//	            RequestDispatcher rd= request.getRequestDispatcher("welcome.jsp");
//	            rd.include(request, response);
//	           }  
//	            catch (Exception e) 
//	           {  
//	            out.println("error");  
//	        }  
		}
		
		else
		{
		String sk="";
		String lang[]=request.getParameterValues("skill");
		for(int i=0;i<lang.length;i++)
		    sk+=lang[i]+",";
		int f=0;
		
		String tm=request.getParameter("time");
		if(tm.length()!=0)
		{
			f=1;
		}
		int x=udl.insertSkill(sk, uid,tm);
		if(x!=0)
		{
			if(f==1)
				request.setAttribute("timemsg","Your Selected Time slot are Successfully Saved");
			request.setAttribute("skillmsg","Your Skills are Successfully Saved");
			request.setAttribute("message",uid);
			request.getRequestDispatcher("welcome.jsp").forward(request,response);
		}
		}
	}
}
