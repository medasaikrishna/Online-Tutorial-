package pro.tutor;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import pro.DB;


@WebServlet("/dispaper")
public class dispaper extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//PrintWriter out=response.getWriter();
		HttpSession session=request.getSession();
		String paper1=(String)session.getAttribute("skill");
		session.setAttribute("skill", paper1);
		if(request.getParameter("skill")==null)
		{
			//out.println("No Papers Found");
			RequestDispatcher rd= request.getRequestDispatcher("tutor.jsp");
			
            rd.include(request, response);
		}
		else
		{
		//PreparedStatement stmt =

		
		//String bookId = request.getParameter("bookId")!=null?request.getParameter("bookId"):"NA";
        
        ServletOutputStream sos;
        Connection  con=null;
        PreparedStatement pstmt=null;
         
        response.setContentType("application/pdf");
 
        response.setHeader("Content-disposition","inline; filename="+paper1+".pdf" );
 
 
         sos = response.getOutputStream();
         
 
           try {
              
               con = DB.getConnection();
          } catch (Exception e) {
                     System.out.println(e);
                     System.exit(0); 
                          }
            
          ResultSet rset=null;
            try {
                pstmt = con.prepareStatement("select paper from paper where about=?"); 
                pstmt.setString(1, paper1);
                rset = pstmt.executeQuery();
                if (rset.next())
                    sos.write(rset.getBytes("paper"));
                else
                    return;
                 
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
     
        sos.flush();
        sos.close();
	}
	}


}
