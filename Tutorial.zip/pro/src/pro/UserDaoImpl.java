package pro;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDaoImpl implements UserDao{
	
	static Connection con;
	static PreparedStatement ps;

	@Override
	public int insert(UserDetails ud) {
		// TODO Auto-generated method stub
		
		int s=0;
		try {
			con=DB.getConnection();
			ps=con.prepareStatement("insert into user values(?,?,?,?,?,?,?,?,?)");
			ps.setString(1,ud.getFname());
			ps.setString(2,ud.getLname());
			ps.setString(3,ud.getDob());
			ps.setString(4,ud.getGender());
			ps.setString(5,ud.getNum());
			ps.setString(6,ud.getUserid());
			ps.setString(7,ud.getPass());
			ps.setString(8,ud.getSecretQ());
			ps.setString(9, ud.getSecretA());
			s=ps.executeUpdate();
			System.out.println("success");
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return s;
	}

	@Override
	public UserDetails getdata(String uname, String pass) {
		// TODO Auto-generated method stub
		
		UserDetails udd=new UserDetails();
		try
		{
			con=DB.getConnection();
			ps=con.prepareStatement("select * from user where userid=? and pass=?");
			ps.setString(1,uname);
			ps.setString(2,pass);
			
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				udd.setFname(rs.getString(1));
				udd.setLname(rs.getString(2));
				udd.setDob(rs.getString(3));
				udd.setGender(rs.getString(4));
				udd.setNum(rs.getString(5));
				udd.setUserid(rs.getString(6));
				udd.setPass(rs.getString(7));
			}
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return udd;
	}

	@Override
	public admin adminDetails(String uname, String pass) {
		
		admin adm=new admin();
		try
		{
			con=DB.getConnection();
			ps=con.prepareStatement("select * from admin");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				adm.setAdminid(rs.getString(1));
				adm.setAdminpass(rs.getString(2));
			}
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return adm;
	}

	@Override
	public String getUserid(String qua, String ans) {
		
		UserDetails udd=new UserDetails();
		
		try
		{
			con=DB.getConnection();
			ps=con.prepareStatement("select userid from user where secretQ=? and secretA=?");
			ps.setString(1,qua);
			ps.setString(2,ans);
			
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				udd.setUserid(rs.getString(1));
			}
		}catch(Exception e)
		{
			System.out.println(e);
		}
		String uid=udd.getUserid();
		return uid;
		
	}

	@Override
	public String getUserpass(String qua, String ans) {
		UserDetails udd=new UserDetails();
		
		try
		{
			con=DB.getConnection();
			ps=con.prepareStatement("select pass from user where secretQ=? and secretA=?");
			ps.setString(1,qua);
			ps.setString(2,ans);
			
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				udd.setPass(rs.getString(1));
			}
		}catch(Exception e)
		{
			System.out.println(e);
		}
		String upass=udd.getPass();
		return upass;
		
	}


	@Override
	public int updateSkill(String uid,String newskl) {
		int x=0;
		try
		{
			con=DB.getConnection();
			ps=con.prepareStatement("update skills set skill=? where uid=?");
			ps.setString(1,newskl);
			ps.setString(2, uid);
			x=ps.executeUpdate();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		
		return x;
	}

	@Override
	public int insertSkill(String str, String uid, String tm) {
		
		int x=0;
		try
		{
			con=DB.getConnection();
			ps=con.prepareStatement("insert into skills values(?,?,?)");
			ps.setString(1,uid);
			ps.setString(2,str);
			ps.setString(3, tm);
			
			 x=ps.executeUpdate();
		}catch(Exception e)
		{
			System.out.println(e);
		}

		return x;
	}

	@Override
	public String getSkill(String uid) {
		
		String x="";
		try
		{
			con=DB.getConnection();
			ps=con.prepareStatement("select * from skills where uid=?");
			ps.setString(1,uid);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				x=rs.getString(2);
			}
			 
		}catch(Exception e)
		{
			System.out.println(e);
		}

		return x;

		
	}

	@Override
	public int inserthelp(String issue, String desc) {


		int x=0;
		
		try
		{
			con=DB.getConnection();
			ps=con.prepareStatement("insert into help(issue,des) values(?,?)");
			ps.setString(1,issue);
			ps.setString(2,desc);
			
		 x=ps.executeUpdate();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		
		return x;
	}

	
	
}
