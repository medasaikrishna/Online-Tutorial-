package pro;

public interface UserDao {
	public int insert(UserDetails ud);
	public UserDetails getdata(String uname,String pass);
	public admin adminDetails(String uname,String pass);
	public String getUserid(String qua,String ans);
	public String  getUserpass(String qua,String ans);
	
	public int insertSkill(String str,String uid,String tm);
	public int updateSkill(String uid,String newskl);
	public String getSkill(String uid);
	public int inserthelp(String issue,String desc);

}
