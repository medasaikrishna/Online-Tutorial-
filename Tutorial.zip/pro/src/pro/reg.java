package pro;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/reg")
public class reg extends HttpServlet {
	private static final long serialVersionUID = 1L;


    public reg() {
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		UserDaoImpl ud=new UserDaoImpl();
		PrintWriter out = response.getWriter(); 
		String uname=request.getParameter("uname");
		String pass=request.getParameter("pass");
		request.setAttribute("user",uname);
		UserDetails udd=ud.getdata(uname, pass);
		
		String id=udd.getUserid();
		String pa=udd.getPass();
		
		out.println("user"+uname);
		
		if(uname.equals(id)&&pass.equals(pa))
		{
			
			HttpSession session=request.getSession();
			session.setAttribute("username",uname);
			request.setAttribute("message",uname);
			request.getRequestDispatcher("welcome.jsp").forward(request,response);
		}
		if(!uname.equals(id))
		{
			request.setAttribute("message","User ID is Not present");
			request.getRequestDispatcher("login.jsp").forward(request,response);
		}
		if(!pass.equals(pa))
		{
			request.setAttribute("message","Password NOT Matching");
			request.getRequestDispatcher("login.jsp").forward(request,response);
		}
	}

}
