package pro;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public register() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out=response.getWriter();
		UserDao ud=new UserDaoImpl();
		UserDetails usd=new UserDetails();
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String dob=request.getParameter("dob");
		String gen=request.getParameter("gender");
		String num=request.getParameter("num");
		String id=request.getParameter("uid");
		String pass=request.getParameter("pass");
		String qua=request.getParameter("question");
		String ans=request.getParameter("sq");
		usd.setFname(fname);
		usd.setLname(lname);
		usd.setDob(dob);
		usd.setGender(gen);
		usd.setNum(num);
		usd.setUserid(id);
		usd.setPass(pass);
		usd.setSecretQ(qua);
		usd.setSecretA(ans);
		if(fname.equalsIgnoreCase("null")||dob.equalsIgnoreCase("null")||num.equalsIgnoreCase("null"))
		{
			out.println("<script type='text/javascript'>");
        	out.println("alert('Fields Cannot be Null');");
        	out.println("</script>");
        	RequestDispatcher rd=request.getRequestDispatcher("register.html");
        	rd.include(request, response);
		}
		else {
			
			
		int x=ud.insert(usd);
		if(x!=0)
		{
		request.setAttribute("sussmessage","New User created Successfully");
		request.getRequestDispatcher("login.jsp").forward(request,response);
		}
		else
		{
			request.setAttribute("sussmessage","Not registered !!!!");
			request.getRequestDispatcher("login.jsp").forward(request,response);
		}
		}
			
	}

}
